﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Program3")> 
<Assembly: AssemblyDescription("Mortgage Calculator Version 3.0")> 
<Assembly: AssemblyCompany("The Molex Group")> 
<Assembly: AssemblyProduct("Program3")> 
<Assembly: AssemblyCopyright("Copyright © The Molex Group 2010")> 
<Assembly: AssemblyTrademark("2010 The Molex Group, All rights reserved")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("56af2f82-a718-4d68-9610-4fd9199b0c87")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
