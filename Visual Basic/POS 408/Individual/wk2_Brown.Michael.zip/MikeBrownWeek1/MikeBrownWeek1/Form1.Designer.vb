﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSalaryCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName1 = New System.Windows.Forms.Label
        Me.lblName2 = New System.Windows.Forms.Label
        Me.lblName3 = New System.Windows.Forms.Label
        Me.lblName4 = New System.Windows.Forms.Label
        Me.lblName5 = New System.Windows.Forms.Label
        Me.lblName6 = New System.Windows.Forms.Label
        Me.txtRate1 = New System.Windows.Forms.TextBox
        Me.txtRate2 = New System.Windows.Forms.TextBox
        Me.txtRate3 = New System.Windows.Forms.TextBox
        Me.txtRate4 = New System.Windows.Forms.TextBox
        Me.txtRate5 = New System.Windows.Forms.TextBox
        Me.txtRate6 = New System.Windows.Forms.TextBox
        Me.txtHours4 = New System.Windows.Forms.TextBox
        Me.txtHours5 = New System.Windows.Forms.TextBox
        Me.txtHours6 = New System.Windows.Forms.TextBox
        Me.txtHours3 = New System.Windows.Forms.TextBox
        Me.txtHours2 = New System.Windows.Forms.TextBox
        Me.txtHours1 = New System.Windows.Forms.TextBox
        Me.btnCalculate = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.lblNameHeader = New System.Windows.Forms.Label
        Me.lblRateHeader = New System.Windows.Forms.Label
        Me.lblHoursHeader = New System.Windows.Forms.Label
        Me.lblPayHeader = New System.Windows.Forms.Label
        Me.lblPay1 = New System.Windows.Forms.Label
        Me.lblPay2 = New System.Windows.Forms.Label
        Me.lblPay3 = New System.Windows.Forms.Label
        Me.lblPay4 = New System.Windows.Forms.Label
        Me.lblPay5 = New System.Windows.Forms.Label
        Me.lblPay6 = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutThisProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HowTOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HowToUseThisProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblName1
        '
        Me.lblName1.AutoSize = True
        Me.lblName1.Location = New System.Drawing.Point(5, 52)
        Me.lblName1.Name = "lblName1"
        Me.lblName1.Size = New System.Drawing.Size(74, 13)
        Me.lblName1.TabIndex = 0
        Me.lblName1.Text = "Sean Connery"
        '
        'lblName2
        '
        Me.lblName2.AutoSize = True
        Me.lblName2.Location = New System.Drawing.Point(0, 112)
        Me.lblName2.Name = "lblName2"
        Me.lblName2.Size = New System.Drawing.Size(85, 13)
        Me.lblName2.TabIndex = 1
        Me.lblName2.Text = "George Lazenby"
        '
        'lblName3
        '
        Me.lblName3.AutoSize = True
        Me.lblName3.Location = New System.Drawing.Point(8, 168)
        Me.lblName3.Name = "lblName3"
        Me.lblName3.Size = New System.Drawing.Size(69, 13)
        Me.lblName3.TabIndex = 2
        Me.lblName3.Text = "Roger Moore"
        '
        'lblName4
        '
        Me.lblName4.AutoSize = True
        Me.lblName4.Location = New System.Drawing.Point(3, 224)
        Me.lblName4.Name = "lblName4"
        Me.lblName4.Size = New System.Drawing.Size(78, 13)
        Me.lblName4.TabIndex = 3
        Me.lblName4.Text = "Timothy Dalton"
        '
        'lblName5
        '
        Me.lblName5.AutoSize = True
        Me.lblName5.Location = New System.Drawing.Point(3, 280)
        Me.lblName5.Name = "lblName5"
        Me.lblName5.Size = New System.Drawing.Size(79, 13)
        Me.lblName5.TabIndex = 4
        Me.lblName5.Text = "Pierce Brosnan"
        '
        'lblName6
        '
        Me.lblName6.AutoSize = True
        Me.lblName6.Location = New System.Drawing.Point(10, 336)
        Me.lblName6.Name = "lblName6"
        Me.lblName6.Size = New System.Drawing.Size(64, 13)
        Me.lblName6.TabIndex = 5
        Me.lblName6.Text = "Daniel Craig"
        '
        'txtRate1
        '
        Me.txtRate1.Location = New System.Drawing.Point(133, 45)
        Me.txtRate1.Name = "txtRate1"
        Me.txtRate1.Size = New System.Drawing.Size(51, 20)
        Me.txtRate1.TabIndex = 6
        Me.txtRate1.Text = "$75/hour"
        '
        'txtRate2
        '
        Me.txtRate2.Location = New System.Drawing.Point(133, 105)
        Me.txtRate2.Name = "txtRate2"
        Me.txtRate2.Size = New System.Drawing.Size(51, 20)
        Me.txtRate2.TabIndex = 7
        Me.txtRate2.Text = "$52/hour"
        '
        'txtRate3
        '
        Me.txtRate3.Location = New System.Drawing.Point(133, 161)
        Me.txtRate3.Name = "txtRate3"
        Me.txtRate3.Size = New System.Drawing.Size(51, 20)
        Me.txtRate3.TabIndex = 8
        Me.txtRate3.Text = "$80/hour"
        '
        'txtRate4
        '
        Me.txtRate4.Location = New System.Drawing.Point(133, 217)
        Me.txtRate4.Name = "txtRate4"
        Me.txtRate4.Size = New System.Drawing.Size(51, 20)
        Me.txtRate4.TabIndex = 9
        Me.txtRate4.Text = "$60/hour"
        '
        'txtRate5
        '
        Me.txtRate5.Location = New System.Drawing.Point(133, 273)
        Me.txtRate5.Name = "txtRate5"
        Me.txtRate5.Size = New System.Drawing.Size(51, 20)
        Me.txtRate5.TabIndex = 10
        Me.txtRate5.Text = "$85/hour"
        '
        'txtRate6
        '
        Me.txtRate6.Location = New System.Drawing.Point(133, 329)
        Me.txtRate6.Name = "txtRate6"
        Me.txtRate6.Size = New System.Drawing.Size(51, 20)
        Me.txtRate6.TabIndex = 11
        Me.txtRate6.Text = "$94/hour"
        '
        'txtHours4
        '
        Me.txtHours4.Location = New System.Drawing.Point(233, 217)
        Me.txtHours4.Name = "txtHours4"
        Me.txtHours4.Size = New System.Drawing.Size(76, 20)
        Me.txtHours4.TabIndex = 12
        Me.txtHours4.Text = "0"
        '
        'txtHours5
        '
        Me.txtHours5.Location = New System.Drawing.Point(233, 273)
        Me.txtHours5.Name = "txtHours5"
        Me.txtHours5.Size = New System.Drawing.Size(76, 20)
        Me.txtHours5.TabIndex = 13
        Me.txtHours5.Text = "0"
        '
        'txtHours6
        '
        Me.txtHours6.Location = New System.Drawing.Point(233, 329)
        Me.txtHours6.Name = "txtHours6"
        Me.txtHours6.Size = New System.Drawing.Size(76, 20)
        Me.txtHours6.TabIndex = 14
        Me.txtHours6.Text = "0"
        '
        'txtHours3
        '
        Me.txtHours3.Location = New System.Drawing.Point(233, 161)
        Me.txtHours3.Name = "txtHours3"
        Me.txtHours3.Size = New System.Drawing.Size(76, 20)
        Me.txtHours3.TabIndex = 15
        Me.txtHours3.Text = "0"
        '
        'txtHours2
        '
        Me.txtHours2.Location = New System.Drawing.Point(233, 105)
        Me.txtHours2.Name = "txtHours2"
        Me.txtHours2.Size = New System.Drawing.Size(76, 20)
        Me.txtHours2.TabIndex = 16
        Me.txtHours2.Text = "0"
        '
        'txtHours1
        '
        Me.txtHours1.Location = New System.Drawing.Point(233, 45)
        Me.txtHours1.Name = "txtHours1"
        Me.txtHours1.Size = New System.Drawing.Size(76, 20)
        Me.txtHours1.TabIndex = 17
        Me.txtHours1.Text = "0"
        '
        'btnCalculate
        '
        Me.btnCalculate.Enabled = False
        Me.btnCalculate.Location = New System.Drawing.Point(11, 386)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 18
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Enabled = False
        Me.btnClear.Location = New System.Drawing.Point(169, 386)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(321, 386)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 20
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblNameHeader
        '
        Me.lblNameHeader.AutoSize = True
        Me.lblNameHeader.Location = New System.Drawing.Point(2, 24)
        Me.lblNameHeader.Name = "lblNameHeader"
        Me.lblNameHeader.Size = New System.Drawing.Size(84, 13)
        Me.lblNameHeader.TabIndex = 21
        Me.lblNameHeader.Text = "Employee Name"
        '
        'lblRateHeader
        '
        Me.lblRateHeader.AutoSize = True
        Me.lblRateHeader.Location = New System.Drawing.Point(133, 24)
        Me.lblRateHeader.Name = "lblRateHeader"
        Me.lblRateHeader.Size = New System.Drawing.Size(51, 13)
        Me.lblRateHeader.TabIndex = 22
        Me.lblRateHeader.Text = "Pay Rate"
        '
        'lblHoursHeader
        '
        Me.lblHoursHeader.AutoSize = True
        Me.lblHoursHeader.Location = New System.Drawing.Point(230, 24)
        Me.lblHoursHeader.Name = "lblHoursHeader"
        Me.lblHoursHeader.Size = New System.Drawing.Size(76, 13)
        Me.lblHoursHeader.TabIndex = 23
        Me.lblHoursHeader.Text = "Hours Worked"
        '
        'lblPayHeader
        '
        Me.lblPayHeader.AutoSize = True
        Me.lblPayHeader.Location = New System.Drawing.Point(359, 24)
        Me.lblPayHeader.Name = "lblPayHeader"
        Me.lblPayHeader.Size = New System.Drawing.Size(64, 13)
        Me.lblPayHeader.TabIndex = 24
        Me.lblPayHeader.Text = "Weekly Pay"
        '
        'lblPay1
        '
        Me.lblPay1.AutoSize = True
        Me.lblPay1.BackColor = System.Drawing.Color.White
        Me.lblPay1.Location = New System.Drawing.Point(368, 52)
        Me.lblPay1.Name = "lblPay1"
        Me.lblPay1.Size = New System.Drawing.Size(171, 13)
        Me.lblPay1.TabIndex = 25
        Me.lblPay1.Text = "Total Pay Amount will Display Here"
        '
        'lblPay2
        '
        Me.lblPay2.AutoSize = True
        Me.lblPay2.Location = New System.Drawing.Point(368, 112)
        Me.lblPay2.Name = "lblPay2"
        Me.lblPay2.Size = New System.Drawing.Size(0, 13)
        Me.lblPay2.TabIndex = 26
        '
        'lblPay3
        '
        Me.lblPay3.AutoSize = True
        Me.lblPay3.Location = New System.Drawing.Point(368, 168)
        Me.lblPay3.Name = "lblPay3"
        Me.lblPay3.Size = New System.Drawing.Size(0, 13)
        Me.lblPay3.TabIndex = 27
        '
        'lblPay4
        '
        Me.lblPay4.AutoSize = True
        Me.lblPay4.Location = New System.Drawing.Point(368, 224)
        Me.lblPay4.Name = "lblPay4"
        Me.lblPay4.Size = New System.Drawing.Size(0, 13)
        Me.lblPay4.TabIndex = 28
        '
        'lblPay5
        '
        Me.lblPay5.AutoSize = True
        Me.lblPay5.Location = New System.Drawing.Point(368, 280)
        Me.lblPay5.Name = "lblPay5"
        Me.lblPay5.Size = New System.Drawing.Size(0, 13)
        Me.lblPay5.TabIndex = 29
        '
        'lblPay6
        '
        Me.lblPay6.AutoSize = True
        Me.lblPay6.Location = New System.Drawing.Point(368, 336)
        Me.lblPay6.Name = "lblPay6"
        Me.lblPay6.Size = New System.Drawing.Size(0, 13)
        Me.lblPay6.TabIndex = 30
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(645, 24)
        Me.MenuStrip1.TabIndex = 31
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.HowTOToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutThisProgramToolStripMenuItem})
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'AboutThisProgramToolStripMenuItem
        '
        Me.AboutThisProgramToolStripMenuItem.Name = "AboutThisProgramToolStripMenuItem"
        Me.AboutThisProgramToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AboutThisProgramToolStripMenuItem.Text = "About This Program"
        '
        'HowTOToolStripMenuItem
        '
        Me.HowTOToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HowToUseThisProgramToolStripMenuItem})
        Me.HowTOToolStripMenuItem.Name = "HowTOToolStripMenuItem"
        Me.HowTOToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HowTOToolStripMenuItem.Text = "How To"
        '
        'HowToUseThisProgramToolStripMenuItem
        '
        Me.HowToUseThisProgramToolStripMenuItem.Name = "HowToUseThisProgramToolStripMenuItem"
        Me.HowToUseThisProgramToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.HowToUseThisProgramToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.HowToUseThisProgramToolStripMenuItem.Text = "How to Use this Program"
        '
        'frmSalaryCalculator
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(645, 550)
        Me.Controls.Add(Me.lblPay6)
        Me.Controls.Add(Me.lblPay5)
        Me.Controls.Add(Me.lblPay4)
        Me.Controls.Add(Me.lblPay3)
        Me.Controls.Add(Me.lblPay2)
        Me.Controls.Add(Me.lblPay1)
        Me.Controls.Add(Me.lblPayHeader)
        Me.Controls.Add(Me.lblHoursHeader)
        Me.Controls.Add(Me.lblRateHeader)
        Me.Controls.Add(Me.lblNameHeader)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtHours1)
        Me.Controls.Add(Me.txtHours2)
        Me.Controls.Add(Me.txtHours3)
        Me.Controls.Add(Me.txtHours6)
        Me.Controls.Add(Me.txtHours5)
        Me.Controls.Add(Me.txtHours4)
        Me.Controls.Add(Me.txtRate6)
        Me.Controls.Add(Me.txtRate5)
        Me.Controls.Add(Me.txtRate4)
        Me.Controls.Add(Me.txtRate3)
        Me.Controls.Add(Me.txtRate2)
        Me.Controls.Add(Me.txtRate1)
        Me.Controls.Add(Me.lblName6)
        Me.Controls.Add(Me.lblName5)
        Me.Controls.Add(Me.lblName4)
        Me.Controls.Add(Me.lblName3)
        Me.Controls.Add(Me.lblName2)
        Me.Controls.Add(Me.lblName1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmSalaryCalculator"
        Me.Text = "Salary Calculator"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblName1 As System.Windows.Forms.Label
    Friend WithEvents lblName2 As System.Windows.Forms.Label
    Friend WithEvents lblName3 As System.Windows.Forms.Label
    Friend WithEvents lblName4 As System.Windows.Forms.Label
    Friend WithEvents lblName5 As System.Windows.Forms.Label
    Friend WithEvents lblName6 As System.Windows.Forms.Label
    Friend WithEvents txtRate1 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate2 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate3 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate4 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate5 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate6 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours4 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours5 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours6 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours3 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours2 As System.Windows.Forms.TextBox
    Friend WithEvents txtHours1 As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblNameHeader As System.Windows.Forms.Label
    Friend WithEvents lblRateHeader As System.Windows.Forms.Label
    Friend WithEvents lblHoursHeader As System.Windows.Forms.Label
    Friend WithEvents lblPayHeader As System.Windows.Forms.Label
    Friend WithEvents lblPay1 As System.Windows.Forms.Label
    Friend WithEvents lblPay2 As System.Windows.Forms.Label
    Friend WithEvents lblPay3 As System.Windows.Forms.Label
    Friend WithEvents lblPay4 As System.Windows.Forms.Label
    Friend WithEvents lblPay5 As System.Windows.Forms.Label
    Friend WithEvents lblPay6 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutThisProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowTOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowToUseThisProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
