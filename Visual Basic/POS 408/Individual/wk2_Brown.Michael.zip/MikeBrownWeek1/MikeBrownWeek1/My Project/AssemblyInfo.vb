﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("MikeBrownWeek1")> 
<Assembly: AssemblyDescription("Calculate Weekly Salaries")> 
<Assembly: AssemblyCompany("The Molex Group")> 
<Assembly: AssemblyProduct("Salary Calculator")> 
<Assembly: AssemblyCopyright("Copyright © The Molex Group 2009")> 
<Assembly: AssemblyTrademark("No Trademark")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("9b7d9394-885b-4121-ac90-e8c0bfa79c8f")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
