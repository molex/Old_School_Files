
To solve the kata you..
  1) implement the kata interface methods
  2) use 'mvn clean install' in the /nasa-countdown-solv-java folder to build and test it
  3) and keep trying until you solve it :-)

The kata details can be found online
under http://www.codingkata.org/katas/unit/nasa-countdown

To learn how you solve a kata in general
browse to http://www.codingkata.org/katas/unit/hello-world

