package org.codingkata.unit;

import org.codingkata.unit.api.BaseKataSolution;

public class MyKata extends BaseKataSolution {

    // YOUR IMPLEMENTATION
    public String reply(){
        return "hello world";
    }

}