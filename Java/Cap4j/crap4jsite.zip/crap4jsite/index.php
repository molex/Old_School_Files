<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- InstanceBegin template="/Templates/home_index.dwt" codeOutsideHTMLIsLocked="false" --><?php
define('WP_USE_THEMES', false);
if (! isset($wp_did_header)):
if ( !file_exists( dirname(__FILE__) . '/news/wp-config.php') ) {
        if (strpos($_SERVER['PHP_SELF'], 'wp-admin') !== false) $path = '';
        else $path = '/news/wp-admin/';

        require_once( dirname(__FILE__) . '/news/wp-includes/classes.php');
        require_once( dirname(__FILE__) . '/news/wp-includes/functions.php');
        require_once( dirname(__FILE__) . '/news/wp-includes/plugin.php');
        wp_die("There doesn't seem to be a <code>wp-config.php</code> file. I need this before we can get started. Need more help? <a \
href='http://codex.wordpress.org/Editing_wp-config.php'>We got it</a>. You can <a href='{$path}setup-config.php'>create a <code>wp-con\
fig.php</code> file through a web interface</a>, but this doesn't work for all server setups. The safest way is to manually create the\
 file.", "WordPress &rsaquo; Error");
}

$wp_did_header = true;

require_once( dirname(__FILE__) . '/news/wp-config.php');

wp();
gzip_compression();
endif;

?>


<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<!-- InstanceBeginEditable name="doctitle" -->
<title>Crap4j Home</title>
<!-- InstanceEndEditable --><!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
<link href="/index.css" rel="stylesheet" type="text/css" />
<!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
.twoColElsLtHdr #sidebar1 { padding-top: 30px; }
.twoColElsLtHdr #mainContent { zoom: 1; padding-top: 15px; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 10px
}

-->
</style>
<!-- InstanceParam name="OptionalSideBar" type="boolean" value="false" -->
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-2823872-1";
urchinTracker();
</script>
<!-- InstanceParam name="sideBar" type="boolean" value="true" -->
</head>

<body class="twoColElsLtHdr" onload="MM_preloadImages('/images/about_on.png','/images/contact_on.png','/images/download_on.png','/images/craporama_on.png','/images/docs_on.png','/images/forums_on.png','/images/get_involved_on.png','/images/crapparel_on.png','/images/news_on.png')">
<div id="container">
  <div id="header">
    <div class="logo">
      <p style="margin:0;margin-top:0" align="center"><a href="http://www.crap4j.org/"><img src="/images/new_banner_tp.png" alt="logo" width="641" height="172" border="0" /></a></p>      
    </div>
    <div class="navbar" style="background-color:#eecc88">
      <p style="margin:0; margin-top:0; padding-top:0;padding-left:0" align="center">
      <a href="/downloads/index.html" target="_top" onclick="MM_nbGroup('down','group1','Download','',1)" onmouseover="MM_nbGroup('over','Download','/images/download_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/download.png" alt="download" name="Download" width="121" height="55" border="0" id="Download" onload="" /></a>
     <a href="docs.html" target="_top" onclick="MM_nbGroup('down','group1','Docs','',1)" onmouseover="MM_nbGroup('over','Docs','/images/docs_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/docs.png" alt="docs" name="Docs" width="85" height="55" border="0" id="Docs" onload="" /></a>
      <a href="/benchmark/stats/" target="_top" onclick="MM_nbGroup('down','group1','Craporama','',1)" onmouseover="MM_nbGroup('over','Craporama','/images/craporama_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/craporama.png" alt="craporama" name="Craporama" width="146" height="56" border="0" id="Craporama" onload="" /></a>  
      <a href="/news/" target="_top" onclick="MM_nbGroup('down','group1','News','',1)" onmouseover="MM_nbGroup('over','News','/images/news_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/news.png" alt="news" name="News" width="87" height="56" border="0" id="News" onload="" /></a>
      <a href="/forums.html" target="_top" onclick="MM_nbGroup('down','group1','Forums','',1)" onmouseover="MM_nbGroup('over','Forums','/images/forums_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/forums.png" alt="forums" name="Forums" width="103" height="55" border="0" id="Forums" onload="" /></a>
      <a href="http://code.google.com/p/crap4j/" target="_top" onclick="MM_nbGroup('down','group1','Get_Involved','',1)" onmouseover="MM_nbGroup('over','Get_Involved','/images/get_involved_on.png','',1)" onmouseout="MM_nbGroup('out')">
      	<img src="/images/get_involved.png" alt="get involved" name="Get_Involved" width="146" height="55" border="0" id="Get_Involved" onload="" /></a>
      <a href="http://www.cafepress.com/crap4j" target="_top" onclick="MM_nbGroup('down','group1','Crapparel','',1)" onmouseover="MM_nbGroup('over','Crapparel','/images/crapparel_on.png','',1)" onmouseout="MM_nbGroup('out')">
        <img src="/images/crapparel.png" alt="crapparel" name="Crapparel" width="121" height="56" border="0" id="Crapparel" onload="" /></a>
        <!-- end #header -->
      </p>
    </div>
  </div>

<div  style="padding-top:0;margin:0;margin-top:0;background-image:url(/images/main_background.gif);border:1px solid #FFFFCC">
      
  <div id="sidebar">
    <div  style="width:18em;text-align:left;padding-left:0;padding-top:0">
      <div align="center"><a href="/news/" target="_top" onclick="MM_nbGroup('down','group2','LatestNews','',1)" onmouseover="MM_nbGroup('over','LatestNews','/images/latest_news_on.png','',1)" onmouseout="MM_nbGroup('out')">
        <img src="/images/latest_news.png" alt="news headline" name="LatestNews" width="216" height="35" border="0" id="LatestNews" onload="" /></a></div>
    </div>
    <div>
    <p   style="width:30em;font-size:10px;text-align:left">
<?php get_header();
		if (have_posts()) :
   			while (have_posts()) : 
      			the_post();
                ?><a style="padding:3px;margin-bottom:2px" href="<?php the_permalink(); ?>">&raquo;&nbsp;<?php the_title();?></a></br><?php
   			endwhile;
            ?>
        <?php else : ?>
	  <p class="center">No news found</p>
		<?php endif; ?>

	  </p>
    </div>
      <div class="social_bookmarks" style="float:left;width:17em">
      <p style="text-align:center" align="center">
    <a href="http://del.icio.us/post?url=http://www.crap4j.org&title=Crap4j Home"
       title="del.icio.us"><img src="/images/social-bookmarks/delicious.gif" alt="del.icio.us" border="0"/></a>&nbsp;
    <a href="http://www.stumbleupon.com/submit?url=http://www.crap4j.org&title=Crap4j Home"
       title="StumbleUpon"><img src="/images/social-bookmarks/stumbleupon.gif" alt="StumbleUpon" border="0"/></a>&nbsp;
    <a href="http://digg.com/submit?phase=2&url=http://www.crap4j.org&title=Crap4j Home"
       title="Digg"><img src="/images/social-bookmarks/digg.gif" alt="Digg" border="0"/></a>&nbsp;
    <a href="http://reddit.com/submit?url=http://www.crap4j.org&title=Crap4j Home"
       title="Reddit"><img src="/images/social-bookmarks/reddit.gif" alt="Reddit" border="0"/></a>&nbsp;
    <a href="http://slashdot.org/bookmark.pl?url=http://www.crap4j.org&title=Crap4j Home"
       title="Slashdot"><img src="/images/social-bookmarks/slashdot.gif" alt="Slashdot" border="0"/></a>&nbsp;
       </p>
   </div>
    
  </div>
  
  <!-- InstanceBeginEditable name="EditRegionMainContent" -->
  <div id="mainContent">
    <h1 align="center" style="margin-top:0;">What is Crap4j?</h1>
    <h1 align="center"><a href="screenshots.html"><img src="images/crap4jreport_main_medium.png" alt="Crap4j report screenshot" width="499" height="590" border="0" /></a></h1>
<p>Crap4j is a Java implementation of the CRAP (Change Risk Analysis and Predictions) software metric – a mildly offensive metric name to help protect you from truly offensive code.<br />
        <br />
      The CRAP metric combines cyclomatic complexity and code coverage from automated tests (e.g. JUnit tests) to help you identify code that might be particularly difficult to understand, test, or maintain – the kind of code that makes developers say: “This is crap!” or, if they are stuck maintaining it, “Oh, crap!”.<br />
      <br />
      The best way to learn more about CRAP and Crap4j is to check the various articles, newsgroups and blogs about them.<br />
      <br />
      CRAP and Crap4j are designed to be open-source and open to discussion, so feel free to jump in.</p>
      <p align="center">
      <!-- end #mainContent -->
      </p>
  </div>
  <!-- InstanceEndEditable -->
  </p>
  <!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
  <div id="footer">
    <div class="style1" id="abouts">
      <p align="center"><a href="/about.html" target="_top" onclick="MM_nbGroup('down','group1','About','',1)" onmouseover="MM_nbGroup('over','About','/images/about_on.png','',1)" onmouseout="MM_nbGroup('out')"><img src="/images/about.png" alt="About" name="About" width="113" height="55" border="0" id="about" onload="" /></a><a href="/contact.html" target="_top" onclick="MM_nbGroup('down','group1','Contact','',1)" onmouseover="MM_nbGroup('over','Contact','/images/contact_on.png','',1)" onmouseout="MM_nbGroup('out')"><img src="/images/contact.png" alt="contact" name="Contact" width="113" height="55" border="0" id="Contact" onload="" /></a></p>
    </div>
</div>
  <!-- end #container --></div>
</body>
<!-- InstanceEnd --></html>
